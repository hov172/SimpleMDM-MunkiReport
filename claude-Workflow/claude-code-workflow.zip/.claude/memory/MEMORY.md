# Memory Index
> Auto-managed by Claude Code (v2.1.59+). Claude reads this at session start.
> Claude writes topic files in this directory as it learns things.
> Browse and edit with `/memory` in any session.
> This directory is gitignored — machine-local, not shared.

## How this works
- You write CLAUDE.md (team rules, project context)
- Claude writes here (what it discovers during sessions)
- Claude reads MEMORY.md as an index, loads topic files only when relevant

## Topic files
<!-- Claude updates this table as it creates files -->

| File | Contains | Last updated |
|---|---|---|
| _(none yet — Claude will create these)_ | | |

## Structured memory layout (Claude follows this)
```
.claude/memory/
├── MEMORY.md          ← this file (index)
├── debugging.md       ← debugging patterns discovered
├── api-conventions.md ← API design decisions learned
├── build-commands.md  ← exact commands that work for this project
└── domain/
    └── *.md           ← domain-specific knowledge by topic
```

## Rules for Claude
1. When you learn something worth remembering, write it to the right file immediately
2. Keep MEMORY.md as a current index with one-line descriptions
3. Entry format: date · what · why — nothing more
4. Read MEMORY.md at session start. Load topic files only when relevant.
5. Before removing any entry, use AskUserQuestion to confirm with the user.
